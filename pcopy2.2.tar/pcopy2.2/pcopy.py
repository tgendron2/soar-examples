#!/usr/bin/env python3
from timeit import default_timer as timer
import sys
import os
import getpass
import json
import requests
import re
import base64
import argparse

class SoarInterface:
    def __init__(self, url, token=None, username=None, password=None, verify_cert=False):
        self.url = None
        self.auth = None
        self.headers = None
        self.verify_cert = verify_cert
        self.session = None
        self.username = username
        self.password = password

        self.default_workbooks = [
            'NIST 800-61', 'Vulnerability Disclosure', 'Risk Investigation', 'Suspicious Email', 'Account Compromise', 'Data Breach',
            'Response Template 1', 'Self-Replicating Malware', 'Network Indicator Enrichment', 'Risk Response'
        ]
        if not url:
            raise RuntimeError("Must provide a URL")
        url = url.rstrip("/")
        if url.endswith("rest"):
            self.url = url
        else:
            self.url = url + "/rest"
        if token:
            self.headers = {"ph-auth-token": token}
        elif username and password:
            self.auth = (username, password)
        else:
            raise RuntimeError("Must provide a token or username and password")
    
    def make_rest_call(self, endpoint, data=None, method="get", session=False):
        headers = {}
        url = self.url
        if session:
            s = self.get_session()
            url = url.rstrip('/rest')
            headers['Referer'] = url
            if method=='post':
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
        else:
            data = json.dumps(data)
            s = requests

        try:
            request_func = getattr(s, method)
        except AttributeError:
            print('{0} attribute not found'.format(method))
            return None
        response = None
        try:
            response = request_func(
                url + endpoint,
                verify=self.verify_cert,
                auth=self.auth,
                data=data,
                headers=headers
            )
        except Exception as e:
            print("Problems connecting to {}".format(url))
            print("Exception: {}".format(e))
            sys.exit(4)

        if response.status_code < 200 or response.status_code > 299:
            if not session and response.json().get('message') == 'not found features':
                print("feature does not exist on target instance")
            elif not session and 'Severity with this Name already exists.' in response.json().get('errors', {}).get('name', []):
                print('Severity with this Name already exists.')
            elif not session and 'already exists in repo' in response.json().get('message'):
                print(response.json()['message'])
            elif not session and response.json().get('message') == 'name: Decided list with this Name already exists.':
                print(f"Custom list with name \'{json.loads(data)['name']}\' already exists")
            elif not session and 'Container status with this Name already exists' in response.json().get('message'):
                print(f"Container status with name \'{json.loads(data)['name']}\' already exists")
            else:
                print("An unsuccessful status code of {0} was returned for {1}.".format(response.status_code, url))
                print(f"Reason: {response.text}")
            return None
        return response

    def set_up_session(self):
        s = requests.Session()
        s.verify = self.verify_cert
        url = self.url.rstrip('/rest')
        s.headers['Referer'] = url + '/soar_login'
        response = s.get(url + '/soar_login', verify=self.verify_cert)
        if response.status_code == 404:
            s.headers['Referer'] = url + '/login'
            response = s.get(url + '/login', verify=self.verify_cert)
        csrf = response.cookies['csrftoken']
        login_resp = s.post(
            url + '/login',
            data={
                'username': self.username,
                'password': self.password,
                'csrfmiddlewaretoken': csrf
            }, verify=self.verify_cert
        )
        login_resp.raise_for_status()
        s.session_id = s.cookies["sessionid"]
        csrf = s.cookies['csrftoken']
        s.headers['X-CSRFToken'] = csrf
        self.session = s
        return self.session
    
    def get_session(self):
        if not self.session:
            return self.set_up_session()
        else:
            return self.session
    
    def get_local_scm(self):
        endpoint = '/scm?page_size=0'
        r = self.make_rest_call(endpoint)
        data = r.json()['data']
        for item in data:
            if item['name'] == 'local':
                return item['id']

    def list_local_playbooks(self):
        scm_local_id = self.get_local_scm()
        if scm_local_id:
            endpoint = f'/playbook?_filter_scm={scm_local_id}&page_size=0'
            r = self.make_rest_call(endpoint)
            return r.json()['data']
        return []
    
    def list_local_custom_functions(self):
        scm_local_id = self.get_local_scm()
        if scm_local_id:
            endpoint = f'/custom_function?_filter_scm={scm_local_id}&page_size=0'
            r = self.make_rest_call(endpoint)
            return r.json()['data']
        return []
    
    def list_workbook_templates(self):
        endpoint = '/workbook_template?page_size=0'
        return self.make_rest_call(endpoint).json()['data']
    
    def list_custom_lists(self):
        endpoint = '/decided_list?page_size=0'
        return self.make_rest_call(endpoint).json()['data']

    def get_workbook_template(self, wb_id, format_for_import=True):
        endpoint = f'/workbook_phase_template?page_size=0&_filter_template={wb_id}'
        r = self.make_rest_call(endpoint)
        if format_for_import:
            workbook_meta = self.make_rest_call(f'/workbook_template/{wb_id}').json()
            phases_json = r.json()['data']
            scrubbed_phases = []
            for phase in phases_json:
                temp_phase = phase
                temp_phase.pop('id')
                temp_phase.pop('create_time')
                temp_phase.pop('modified_time')
                temp_phase.pop('template')
                scrubbed_tasks = []
                for task in phase['tasks']:
                    temp_task = task
                    temp_task.pop('create_time')
                    temp_task.pop('modified_time')
                    temp_task.pop('id')
                    scrubbed_tasks.append(temp_task)
                temp_phase['tasks'] = scrubbed_tasks
                scrubbed_phases.append(temp_phase)

            template = {
                'name': workbook_meta['name'],
                'is_default': workbook_meta['is_default'],
                'phases': scrubbed_phases
            }
            return template
        return r.json()['data']
    
    def test_connectivity(self):
        r = self.make_rest_call('/container')
        if not r:
            return False
        return True
    
def clean_json(item, data):

    if item == "system_settings":
        new_data = {}
        for key, value in data.items():
            if key not in ["audit_trail_settings", "auth_settings"]:
                new_data['feature'] = key
                new_data['set_feature_enabled'] = value['enabled']
            else:
                new_data = data

    elif item == "custom_fields":
        new_data = {}
        new_data['update_container_custom_fields'] = True
        new_data['fields'] = json.dumps(data)

    elif item == "role":
        new_data = []
        for item in data['data']:
            new_item = item
            if new_item['immutable'] is True:
                continue
            if new_item.get('description') == 'Imported from Splunk':
                continue
            del new_item['id']
            new_data.append(new_item)

    elif item == "cef":
        new_data = []
        for item in data['data']:
            new_item = item
            if new_item['type'] == "default":
                continue
            del new_item['id']
            new_data.append(new_item)

    elif item == "container_status":
        new_data = []
        for item in data['data']:
            new_item = item
            if new_item['is_default'] is True or new_item['is_mutable'] is False:
                continue
            del new_item['id']
            del new_item['disabled']
            new_data.append(new_item)

    elif item == "severity":
        new_data = []
        for item in data['data']:
            new_item = item
            if new_item['name'] in ["high", "medium", "low"]:
                continue
            del new_item['id']
            del new_item['disabled']
            new_data.append(new_item)

    elif item == "labels":
        new_data = []
        for item in data['label']:
            new_item = {}
            new_item['add_label'] = True
            new_item['label_name'] = item
            new_data.append(new_item)

    elif item == "tags":
        new_data = []
        for item in data['tags']:
            new_item = {}
            new_item['add_tag'] = True
            new_item['tag_name'] = item
            new_data.append(new_item)

    elif item == "container_pin_settings":
        new_data = []
        for item in data['data']:
            new_item = item
            del item['id']
            new_data.append(new_item)
            
    return new_data

def get_login():
    print("Username: ", end="")
    username = input()
    password = getpass.getpass("Password: ")
    if not username:
        print("Must specify a username to authenticate to Phantom.")
        sys.exit(2)

    if not password:
        print("Must specify a password to authenticate to Phantom.")
        sys.exit(3)
    return username, password

def get_full_login(source=True):
    if source:
        print("Original hostname: ", end="")
    else:
        print("Target hostname: ", end="")
    instance = input()
    print("Username: ", end="")
    username = input()
    password = getpass.getpass("Password: ")
    if not username:
        print("Must specify a username to authenticate to Phantom.")
        sys.exit(2)

    if not password:
        print("Must specify a password to authenticate to Phantom.")
        sys.exit(3)
    if not instance.startswith('http'):
        instance = f'https://{instance}'
    if instance.endswith('/rest'):
        instance = instance.replace('/rest', '')
    if instance.endswith('/'):
        instance = instance.rstrip('/')
    return instance, username, password


def write_response(filepath, resp_content):
    if resp_content:
        file_content = resp_content.json()
        with open(filepath, "w") as f:
            json.dump(file_content, f)

def get_config(soar_instance):
    for item, value in ITEMS.items():
        if value is False:
            continue 

        if item == "system_settings":
            for inner_item, inner_value in value.items():
                if inner_value is False:
                    continue 
                print(f'Getting {inner_item} setting')
                endpoint = "/" + item + '?sections=["' + inner_item + '"]'
                filepath = OUTPUT_DIR + "/" + item + "_" + inner_item + ".json"
                write_response(filepath, soar_instance.make_rest_call(endpoint))
        elif item in ["tags", "labels"]:
            print(f'Getting {item} setting')
            endpoint = "/container_options"
            filepath = OUTPUT_DIR + "/" + item + ".json"
            write_response(filepath, soar_instance.make_rest_call(endpoint))
        elif item in ["custom_fields"]:
            print(f'Getting {item} setting')
            endpoint = "/custom_container_fields/"
            filepath = OUTPUT_DIR + "/" + item + ".json"
            write_response(filepath, soar_instance.make_rest_call(endpoint, method="get", session=True))
        else:
            print(f'Getting {item} setting')
            endpoint = "/" + item + "?page_size=0"
            filepath = OUTPUT_DIR + "/" + item + ".json"
            write_response(filepath, soar_instance.make_rest_call(endpoint))
    return

def put_config(soar_instance):
    for item, value in ITEMS.items():
        if value is False:
            continue

        if item == "system_settings":
            for inner_item, inner_value in value.items():
                if inner_value is False:
                    continue 
                print(f'Uploading {inner_item}')
                with open(OUTPUT_DIR + "/system_settings_" + inner_item + ".json", "r") as f:
                    post_body = clean_json(item, json.loads(f.read()))
                endpoint = "/" + item
                if inner_item not in ["audit_trail_settings", "auth_settings"]:
                    endpoint = "/features"
                soar_instance.make_rest_call(endpoint, post_body, "post")
        elif item == "labels":
            print(f'Uploading {item}')
            with open(OUTPUT_DIR + "/" + item + ".json", "r") as f:
                post_bodies = clean_json(item, json.loads(f.read()))
            endpoint = "/system_settings/events/"
            print(f'Found {len(post_bodies)} labels in local directory')
            count = 0
            for post_body in post_bodies:
                r = soar_instance.make_rest_call(endpoint, post_body, "post")
                if r:
                    count += 1
            print(f'Successfully uploaded {count} labels')
        elif item == "tags":
            print(f'Uploading {item}')
            with open(OUTPUT_DIR + "/" + item + ".json", "r") as f:
                post_bodies = clean_json(item, json.loads(f.read()))
            endpoint = "/admin/admin_settings/tags/"
            print(f'Found {len(post_bodies)} tags in local directory')
            count = 0
            for post_body in post_bodies:
                data = f"add_tag=true&tag_name={post_body['tag_name']}"
                r = soar_instance.make_rest_call(endpoint, data, "post", session=True)
                if r:
                    count += 1
            print(f'Successfully uploaded {count} tags')
        elif item == "custom_fields":
            print(f'Uploading {item}')
            with open(OUTPUT_DIR + "/" + item + ".json", "r") as f:
                post_body = clean_json(item, json.loads(f.read()))
            endpoint = "/system_settings/events/"
            soar_instance.make_rest_call(endpoint, post_body, "post")
        else:
            print(item, value)
            endpoint = "/" + item
            with open(OUTPUT_DIR + "/" + item + ".json", "r") as f:
                post_bodies = clean_json(item, json.loads(f.read()))
            for post_body in post_bodies:
                soar_instance.make_rest_call(endpoint, post_body, "post")
    return



def transfer_playbook(soar_interface_1, soar_interface_2, pb_id):
    endpoint = f'/playbook/{pb_id}/export'
    r = soar_interface_1.make_rest_call(endpoint)
    base64_bytes = base64.b64encode(r.content)
    base64_string = base64_bytes.decode('utf-8')
    new_endpoint = '/import_playbook'
    data = {
        'playbook': base64_string,
        'scm': 'local'
    }
    r = soar_interface_2.make_rest_call(new_endpoint, data=data, method='post')
    if r:
        return r.json()

def transfer_custom_function(soar_interface_1, soar_interface_2, cf_id):
    endpoint = f'/custom_function/{cf_id}/export'
    r = soar_interface_1.make_rest_call(endpoint)
    base64_bytes = base64.b64encode(r.content)
    base64_string = base64_bytes.decode('utf-8')
    new_endpoint = '/import_custom_function'
    data = {
        'custom_function': base64_string,
        'scm': 'local'
    }
    r = soar_interface_2.make_rest_call(new_endpoint, data=data, method='post')
    if r:
        return r.json()

def transfer_custom_list(soar_interface_1, soar_interface_2, list_id):
    endpoint = f'/decided_list/{list_id}'
    r_json = soar_interface_1.make_rest_call(endpoint).json()
    data = {
        'content': r_json['content'],
        'name': r_json['name']
    }
    new_endpoint = f'/decided_list'
    r = soar_interface_2.make_rest_call(new_endpoint, data=data, method='post')
    if r:
        return r.json()

def transfer_workbook(soar_interface_1, soar_interface_2, wb_id):
    template = soar_interface_1.get_workbook_template(wb_id, format_for_import=True)
    endpoint = '/workbook_template/'
    r = soar_interface_2.make_rest_call(endpoint, data=template, method='post')
    if r:
        return r.json()
    
    

def transfer_config(soar_interface_1, soar_interface_2):
    for item, value in TRANSFER_ITEMS.items():
        if value is False:
            continue
        
        if item == 'playbooks':
            print(item, value)
            playbook_list = soar_interface_1.list_local_playbooks()
            for pb in playbook_list:
                response_json = transfer_playbook(soar_interface_1, soar_interface_2, pb['id'])
                if response_json:
                    print(response_json['message'])
        if item == 'custom_functions':
            print(item, value)
            custom_function_list = soar_interface_1.list_local_custom_functions()
            for cf in custom_function_list:
                response_json = transfer_custom_function(soar_interface_1, soar_interface_2, cf['id'])
                if response_json:
                    print(response_json['message'])
        if item == 'custom_lists':
            print(item, value)
            custom_lists_list = soar_interface_1.list_custom_lists()
            for cl in custom_lists_list:
                response_json = transfer_custom_list(soar_interface_1, soar_interface_2, cl['id'])
                if response_json and response_json['success']:
                    print(f"Succesfully transfered \'{cl['name']}\'")
        if item == 'workbooks' and value['transfer']:
            print(item, value)
            template_list = soar_interface_1.list_workbook_templates()
            transfer_list = []
            if value['exclude_default']:
                for item in template_list:
                    exclude = False
                    for default_item in soar_interface_1.default_workbooks:
                        if item['name'] == default_item:
                            exclude = True
                            break
                    if not exclude:
                        transfer_list.append(item)
            else:
                transfer_list = template_list
            for item in transfer_list:
                result = transfer_workbook(soar_interface_1, soar_interface_2, item['id'])
                if result and result['success']:
                    print(f"Transfered workbook: \'{item['name']}\'")

    return

def set_up_args():
    parser = argparse.ArgumentParser(
        prog="pcopy",
        description="Script to transfer config and user-created content from one SOAR instance to another"
    )
    parser.add_argument("--get", "-g", help="GET config from target SOAR instance", metavar="https://example.soar.splunkcloud.com")
    parser.add_argument("--put", "-p", help="PUT existing settings stored locally on target SOAR instance", metavar="https://example.soar.splunkcloud.com")
    parser.add_argument("--transfer", "-t", help="Transfer user created content from one SOAR instance to the other", action='store_true')
    if len(sys.argv)==1:
        parser.print_help()
        # parser.print_usage() # for just the usage line
        parser.exit()
    args = parser.parse_args()                              
    return args
    
if __name__ == "__main__":

    with open('pcopy_config.json') as f:
        pcopy_config = json.loads(f.read())
    VERIFY_CERT = pcopy_config['VERIFY_CERT']   
    ITEMS = pcopy_config['ITEMS']
    OUTPUT_DIR = pcopy_config['OUTPUT_DIR']
    TRANSFER_ITEMS = pcopy_config['TRANSFER_ITEMS']

    if VERIFY_CERT is False:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)\
    

    args = set_up_args()

    try:
        if not os.path.exists(OUTPUT_DIR):
            os.makedirs(OUTPUT_DIR)
    except:
        print("Error creating output directory: {}".format(OUTPUT_DIR))
        sys.exit(7)

    if args.get or args.put:
        if args.get:
            BASE_URL = f"{args.get.rstrip('/')}/rest"
        else:
            BASE_URL = f"{args.put.rstrip('/')}/rest"
        USERNAME, PASSWORD = get_login()
        soar_interface = SoarInterface(BASE_URL, username=USERNAME, password=PASSWORD, verify_cert=VERIFY_CERT)
        if not soar_interface.test_connectivity():
            print('Invalid credentials. Exiting')
            quit()
        if args.get:
            get_config(soar_interface)
        elif args.put:
            put_config(soar_interface)
    elif args.transfer:
        source_host, source_un, source_pw = get_full_login(source=True)
        dest_host, dest_un, dest_pw = get_full_login(source=False)
        source_url = f"{source_host}/rest"
        dest_url = f"{dest_host}/rest"
        source_interface = SoarInterface(source_url, username=source_un, password=source_pw, verify_cert=VERIFY_CERT)
        if not source_interface.test_connectivity():
            print(f'Invalid credentials on {source_url}. Exiting')
            quit()
        dest_interface = SoarInterface(dest_url, username=dest_un, password=dest_pw, verify_cert=VERIFY_CERT)
        if not dest_interface.test_connectivity():
            print(f'Invalid credentials on {dest_url}. Exiting')
            quit()
        transfer_config(source_interface, dest_interface)



